// Tempatkan kode WeCaregiversLanding di sini
export default function WeCaregiversLanding() {
  return <h1 className="text-3xl font-bold text-center text-blue-900">We Caregivers Landing Page</h1>;
}
