# We Caregivers Landing Page

Landing page modern & interaktif untuk perusahaan **We Caregivers**.

## 🚀 Jalankan lokal
```bash
npm install
npm run dev
```

## 🌐 Deploy ke Vercel
- Build command: `npm run build`
- Output directory: `dist`
